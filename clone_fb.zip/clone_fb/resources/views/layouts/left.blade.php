<div class="col-sm-3">
    <div class="sidebar">
        <a href="{{route('dashboard')}}">News Feed</a>
        <a href="{{route('profile.index')}}">Profile</a>
        <a href="{{route('logout')}}">Logout</a>

    </div>
</div>
