<div class="footer no-shadow">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                &copy; FaceClone 2022.
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\clone_fb\resources\views/layouts/footer.blade.php ENDPATH**/ ?>