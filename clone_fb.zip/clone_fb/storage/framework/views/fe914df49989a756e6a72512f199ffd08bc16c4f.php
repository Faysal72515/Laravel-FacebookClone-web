<?php $__env->startSection('center'); ?>
    <div class="col-sm-6">
        <div class="post col-sm-12" id="new_post">
            <div class="row post-heading" style="background: #2d9a40;">
                <div class="col-sm-12">
                    <h4 id="post-header">Create New Post</h4><br/>

                </div>
            </div>
            <div class="row" style="padding: 10px;">
                <form method="POST" action="<?php echo e(route('posts.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <textarea name="status" placeholder="Whats up?" maxlength="250"></textarea>

                        <?php if($errors->has('status')): ?>
                            <div class="alert alert-danger">
                                <?php echo e($errors->first('status')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <br>

                    <div class="form-group">
                        <div class="pull-left">
                            <label class="btn btn-success"><input name="image" type="file" style="display: none;"/>Add Image</label>
                            <?php if($errors->has('image')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e($errors->first('image')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="pull-right">
                            <button class="btn btn-primary">POST</button>
                        </div>
                        <br>
                    </div>
                </form>
            </div>

        </div>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post col-sm-12" id="post_1">
                <div class="row post-heading">
                    <div class="col-sm-12">
                        <a href="<?php echo e(route('profile.index')); ?>">
                            <img src="<?php echo e(asset(auth()->user()->image)?? '/images/no_user.jpg'); ?>" class="profile-picture pull-left"/>
                            &nbsp;
                            <span class="post-user-name"><?php echo e($post['user']->fname.' '.$post['user']->lname); ?></span><br/>
                            &nbsp;
                            <small class="post-date text-mute"><?php echo e($post['created_at']); ?></small>
                        </a>
                    </div>
                </div>
                <div class="row post-body">
                    <div class="col-sm-12">
                        <?php echo e($post['status']); ?>

                    </div>
                    <div class="col-sm-12">
                        <img src="<?php echo e($post['photo']); ?>" height="200" width="300">
                    </div>
                </div>
                <div class="row post-action">
                    <ul class="post-action-menu">
                        <li><a href="javascript:void(0);" class="text-mute" onclick="like(<?php echo e($post['id']); ?>);">Like</a></li>
                        <li><a href="javascript:void(0);" class="text-mute" onclick="share(<?php echo e($post['id']); ?>);">Share</a></li>
                        <li><a href="javascript:void(0);" class="text-mute" onclick="comment(<?php echo e($post['id']); ?>);">Comment</a></li>
                        <li class="pull-right"><a href="#" class="text-mute"><span id="post_share_count_1"><?php echo e($post['shares']); ?></span> Shares</a></li>
                        <li class="pull-right"><a href="#" class="text-mute"><span id="post_comment_count_1"><?php echo e($post['comments']); ?></span> Comments</a></li>
                        <li class="pull-right"><a href="#" class="text-mute"><span id="post_like_count_1"><?php echo e($post['likes']); ?></span> Likes</a></li>
                    </ul>
                </div>

                <div class="post-comment" id="post_comment_<?php echo e($post['id']); ?>" style="display: none;">
                    <?php
                        $all_comments= \App\Models\Comment::where('post_id', $post['id'])->get();
                    ?>

                    <?php $__currentLoopData = $all_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $user= \App\Models\User::where('id', $comm->user_id)->first();
                        ?>
                        <div class="row">
                            <div class="col-sm-1">
                                <a href="javascript:void(0);">
                                    <img src="<?php echo e(asset($user->image)); ?>" class="profile-picture-small pull-left"/>
                                </a>
                            </div>

                            <div class="col-sm-11">
                                <a href="javascript:void(0);">
                                    <span class="post-user-name"><?php echo e($user->fname.' '.$user->lname); ?></span>
                                </a>
                                <?php echo e($comm->comment); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="row">
                        <form action="<?php echo e(route('saveComment')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="col-sm-1 form-group">
                                <a href="profile.html">
                                    <img src="<?php echo e(asset(auth()->user()->image ?? '/images/no_user.jpg')); ?>" class="profile-picture-small pull-left"/>
                                </a>
                            </div>

                            <div class="col-sm-9 form-group">
                                <textarea rows="1" name="comment" class="comment-text" placeholder="Add Comment" oninput="auto_height(this)"></textarea>
                            </div>

                            <div class="col-sm-2 form-group">
                                <input type="hidden" name="post_id" value="<?php echo e($post['id']); ?>">
                                <button type="submit" class="btn btn-success btn-xs">Comment</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    function like(post_id){
        var elem = document.getElementById("post_like_count_"+post_id);
        var count = parseInt(elem.innerHTML);

        $.ajax({
            url: '<?php echo e(route('updateLikes')); ?>',
            type: 'POST',
            dataType: 'json',
            async: false,
            data: {
                post_id: post_id,
                _token: '<?php echo e(csrf_token()); ?>'
            },
            success: function (data){
                if(data.success){
                    elem.innerHTML = count + parseInt(data.result);
                    highlight(elem);
                }
            }

        });



    }
    function share(id){
        var elem = document.getElementById("post_share_count_"+id);
        var count = parseInt(elem.innerHTML);
        elem.innerHTML = count+1;
        highlight(elem);
    }

    function comment(post_id){
        var elem = $('#post_comment_'+post_id);

        if(elem.is(":visible")){
            elem.hide();
        } else{
            elem.show();
        }

    }
    function highlight(elem){
        elem.style.color = "red";
        elem.parentElement.parentElement.style.transform="scale(1.5)";
        setTimeout(function(){
            elem.style.color="";
            elem.parentElement.parentElement.style.transform="scale(1)";
        },300);
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clone_fb\resources\views/dashboard.blade.php ENDPATH**/ ?>