<?php
    $users= \App\Models\User::where('id', '!=', auth()->user()->id)->get();
    $time= now()->subMinutes(10);

    $active_users= \App\Models\User::where('last_login', '>=', $time)->pluck('id')->toArray();
?>

<div class="col-sm-3 chat-users">
    <div class="row">
        <h3>Active Users</h3>
    </div>
    <div class="row">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-12 chat-user
            <?php if(in_array($user->id, $active_users)): ?>
                online
            <?php endif; ?>
        ">
            <a href="#">
                <img src="<?php echo e(asset($user->image)?? '/images/no_user.jpg'); ?>" class="pull-left"/>
                &nbsp;
                <?php echo e($user->fname.' '.$user->lname); ?>

            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\clone_fb\resources\views/layouts/right.blade.php ENDPATH**/ ?>