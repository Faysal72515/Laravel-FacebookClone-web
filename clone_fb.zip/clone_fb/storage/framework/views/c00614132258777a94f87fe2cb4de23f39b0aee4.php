<div class="col-sm-3">
    <div class="sidebar">
        <a href="<?php echo e(route('dashboard')); ?>">News Feed</a>
        <a href="<?php echo e(route('profile.index')); ?>">Profile</a>
        <a href="<?php echo e(route('logout')); ?>">Logout</a>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\clone_fb\resources\views/layouts/left.blade.php ENDPATH**/ ?>